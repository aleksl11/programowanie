public class Main {
    public static void main(String[] args) {
        zadanie1();
    }
    public static void zadanie1(){
        Punkt a=new Punkt();
        Punkt b=new Punkt(1,2);
        Punkt c=new Punkt(-1,3);
        a.setX(5);
        b.setY(a.getX());
        c.setY(-3);
        c.zeruj();
        b.przesun(2,2);
        a.opis();
        b.opis();
        c.opis();
        Okrag kolo=new Okrag();
        kolo.setPromien(4);
        kolo.setSrodek(c);
        System.out.println(kolo.wSrodku(c));
        System.out.println(kolo.wSrodku(a));
        Prostokat p1=new Prostokat(2,3,"zielony");
        p1.przesun(3,5);

    }
}