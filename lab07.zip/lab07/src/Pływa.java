public interface Pływa {
    void plyn();

}
