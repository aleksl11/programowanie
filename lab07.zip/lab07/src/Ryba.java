public abstract class Ryba {

}
