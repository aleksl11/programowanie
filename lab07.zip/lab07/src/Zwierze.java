public abstract class Zwierze implements Plywanie,Latanie{
    @Override
    public void wyladuj() {
        System.out.println("Wyladuj");
    }

    @Override
    public void lec() {
        System.out.println("Lec");
    }

    @Override
    public void plyn() {
        System.out.println("Plyn");
    }

    @Override
    public void wynurz() {
        System.out.println("Wynurz");
    }

    @Override
    public void zanurz() {
        System.out.println("Zanurz");
    }
}
