public class Statek implements Pływa{
    @Override
    public void plyn() {
        System.out.println("Statek plywa");
    }
}
