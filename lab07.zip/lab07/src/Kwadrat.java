

class Kwadrat extends Prostokat{
	Kwadrat(int bok,String kolor){
		super(bok,bok,kolor);
	}
}