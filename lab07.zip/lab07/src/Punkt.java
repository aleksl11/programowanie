
public class Punkt {
	//pola
    int x = 0;
    int y = 0;
    // konstruktor
    Punkt(int x, int y) {
        this.x = x;
        this.y = y;
    }
}