public class Ptak {

}
