public class Samolot implements Lata{

    public void lec() {
        System.out.println("Samolot lata");
    }
}
