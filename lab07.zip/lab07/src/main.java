
class main
{
	public static void main(String[] arg)
	{
		z1();
		
	}
	public static void z1(){
		Samolot sm1=new Samolot();
		sm1.lec();
		Statek st1=new Statek();
		st1.plyn();
	}
	public static void z2(){

	}
}